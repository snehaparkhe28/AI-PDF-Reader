from fastapi import FastAPI, UploadFile, File
import fitz  # PyMuPDF
import openai

app = FastAPI()

OPENAI_API_KEY = "your-openai-api-key"

def extract_text_from_pdf(pdf_file):
    doc = fitz.open(pdf_file)
    text = "\n".join(page.get_text() for page in doc)
    return text

@app.post("/upload_pdf/")
async def upload_pdf(file: UploadFile = File(...)):
    content = await file.read()
    with open("temp.pdf", "wb") as f:
        f.write(content)
    text = extract_text_from_pdf("temp.pdf")
    return {"text": text}

@app.post("/ask/")
async def ask_ai(question: str, text: str):
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "You are a helpful AI PDF assistant."},
                  {"role": "user", "content": f"Document content:\n{text}\nQuestion: {question}"}],
        api_key=OPENAI_API_KEY
    )
    return {"answer": response['choices'][0]['message']['content']}
