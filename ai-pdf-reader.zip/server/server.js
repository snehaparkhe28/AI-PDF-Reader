const express = require("express");
const multer = require("multer");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const upload = multer({ dest: "uploads/" });

app.post("/upload", upload.single("file"), async (req, res) => {
    const file = req.file;
    const response = await axios.post("http://localhost:8000/upload_pdf/", 
        { file: file },
        { headers: { "Content-Type": "multipart/form-data" } }
    );
    res.json(response.data);
});

app.post("/ask", async (req, res) => {
    const { question, text } = req.body;
    const response = await axios.post("http://localhost:8000/ask/", { question, text });
    res.json(response.data);
});

app.listen(5000, () => console.log("Server running on port 5000"));
