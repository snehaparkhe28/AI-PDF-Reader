import { useState } from "react";
import axios from "axios";
import FileUpload from "../components/FileUpload";

export default function Home() {
  const [text, setText] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");

  const handleAsk = async () => {
    const response = await axios.post("http://localhost:5000/ask", { question, text });
    setAnswer(response.data.answer);
  };

  return (
    <div>
      <h1>AI PDF Reader</h1>
      <FileUpload setText={setText} />
      <textarea value={text} readOnly rows={10} cols={50}></textarea>
      <input type="text" placeholder="Ask a question..." value={question} onChange={(e) => setQuestion(e.target.value)} />
      <button onClick={handleAsk}>Ask</button>
      <p>Answer: {answer}</p>
    </div>
  );
}
