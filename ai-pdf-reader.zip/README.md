# AI PDF Reader

This project allows users to upload PDFs and ask questions using AI.
